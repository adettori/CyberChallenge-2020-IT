<?php

echo '<html lang="en">
	<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">		
	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="jumbotron col-md-12 text-center"><h1>GoldNaN Shacks: Reloaded</h1></div>
			</div>
			<div class="row">
';

?>
